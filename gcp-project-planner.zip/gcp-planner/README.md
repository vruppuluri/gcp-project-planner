# GCP Project Planner

A production-ready React web application for managing GCP cloud infrastructure projects — with task tracking, Gantt timeline, resource management, stakeholder mapping, Terraform snippets, and GitHub integration guidance.

**Stack:** React 18 + Vite → Docker → Cloud Run (GCP)  
**AI features:** "Add Task with AI" calls the Anthropic API to suggest GCP-specific tasks

---

## Local Development

```bash
npm install
npm run dev
# → http://localhost:8080
```

---

## Deploy to GCP Cloud Run

### Prerequisites
- GCP project with billing enabled
- `gcloud` CLI authenticated (`gcloud auth login`)
- Artifact Registry API, Cloud Run API, Cloud Build API enabled

### 1. Enable required APIs

```bash
gcloud services enable \
  run.googleapis.com \
  artifactregistry.googleapis.com \
  cloudbuild.googleapis.com \
  --project YOUR_PROJECT_ID
```

### 2. Build & push the container

```bash
PROJECT_ID=your-gcp-project-id
REGION=us-central1

# Create Artifact Registry repo
gcloud artifacts repositories create gcp-planner \
  --repository-format=docker \
  --location=$REGION \
  --project=$PROJECT_ID

# Authenticate Docker
gcloud auth configure-docker $REGION-docker.pkg.dev

# Build & push
IMAGE="$REGION-docker.pkg.dev/$PROJECT_ID/gcp-planner/app:latest"
docker build -t $IMAGE .
docker push $IMAGE
```

### 3. Deploy to Cloud Run

```bash
gcloud run deploy gcp-planner-prod \
  --image $IMAGE \
  --region $REGION \
  --platform managed \
  --allow-unauthenticated \
  --port 8080 \
  --memory 512Mi \
  --cpu 1 \
  --min-instances 0 \
  --max-instances 10 \
  --project $PROJECT_ID
```

### 4. (Optional) Deploy infrastructure with Terraform

```bash
cd terraform
cp terraform.tfvars.example terraform.tfvars
# Edit terraform.tfvars with your values

terraform init \
  -backend-config="bucket=YOUR_TF_STATE_BUCKET"

terraform plan
terraform apply
```

---

## GitHub Actions CI/CD

Copy `deploy/deploy.yml` to `.github/workflows/deploy.yml` and set these repository secrets:

| Secret | Description |
|--------|-------------|
| `GCP_PROJECT_ID` | Your GCP project ID |
| `GCP_SA_KEY` | JSON key for a service account with Cloud Run + Artifact Registry roles |
| `SLACK_WEBHOOK_URL` | (Optional) Slack webhook for deploy notifications |

**Pipeline stages:**
- **PR:** lint → build → `terraform plan` posted as PR comment
- **Merge to main:** build container → push to Artifact Registry → deploy to Cloud Run → Slack notify

---

## Project Structure

```
gcp-project-planner/
├── src/
│   ├── App.jsx          # Main React app (all tabs, AI task modal)
│   └── main.jsx         # React entry point
├── index.html
├── vite.config.js
├── package.json
├── Dockerfile           # Multi-stage: node:20 build → nginx:alpine serve
├── nginx.conf           # SPA routing + Cloud Run PORT injection
├── terraform/
│   ├── main.tf          # Cloud Run, Artifact Registry, Cloud Build, IAM, Armor
│   ├── variables.tf
│   ├── outputs.tf
│   └── terraform.tfvars.example
└── deploy/
    └── deploy.yml       # GitHub Actions workflow
```

---

## Multi-project usage

This app is designed to be **deployed once per GCP project**. To manage multiple projects:

1. Deploy separate Cloud Run instances per project, each with a unique `--tag` or service name.
2. Use a **shared VPC host project** and deploy the planner into each service project.
3. Or use a single deployment and pass `?project=PROJECT_ID` as a query param, then load project config from Cloud Firestore or Cloud Storage.

---

## Security notes

- The AI "Add Task" feature calls the Anthropic API. In production, proxy this through a backend service (Cloud Run function) so the API key is never exposed client-side.
- For internal-only access, remove `allUsers` IAM binding and configure **Identity-Aware Proxy (IAP)** on the Cloud Run service.
- Enable `enable_armor = true` in Terraform to add Cloud Armor WAF rules.
